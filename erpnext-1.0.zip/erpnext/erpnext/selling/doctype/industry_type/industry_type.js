// Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
// License: GNU General Public License v3. See license.txt

//--------- ONLOAD -------------
cur_frm.cscript.onload = function (doc, cdt, cdn) {};

cur_frm.cscript.refresh = function (doc, cdt, cdn) {};
