frappe.treeview_settings["Customer Group"] = {
	ignore_fields: ["parent_customer_group"],
};
