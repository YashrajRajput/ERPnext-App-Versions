frappe.listview_settings["Company"] = {
	onload() {
		frappe.breadcrumbs.add("Accounts");
	},
};
