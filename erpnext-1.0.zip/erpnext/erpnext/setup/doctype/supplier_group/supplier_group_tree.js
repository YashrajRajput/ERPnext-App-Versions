frappe.treeview_settings["Supplier Group"] = {
	breadcrumbs: "Buying",
	ignore_fields: ["parent_supplier_group"],
};
