## Sponsors

#### Features

<table style="width: 100%">
	<tbody>
		<tr>
			<td style="width: 30%">
				<a href="http://www.mcleans.net.au">McLean Images</a>
			</td>
			<td>
				Credit period setting options
				for Customer <a href="https://github.com/frappe/erpnext/issues/3451">#3451</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="http://www.strellagroup.com">Strella Consulting Sdn Bhd</a>
			</td>
			<td>
				Sales / Purchase Return Enhancement <a href="https://github.com/frappe/erpnext/issues/3582">#3582</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				PT. Ridho Sribumi Sejahtera
			</td>
			<td>
				Additional Costs in Stock Entry <a href="https://github.com/frappe/erpnext/issues/3613">#3613</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="http://www.rigpl.com">Rohit Industries</a>
			</td>
			<td>
				Mandrill Integration <a href="https://github.com/frappe/erpnext/issues/3546">#3546</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="http://www.gps.gt">Startrack</a>
			</td>
			<td>
				Delivery to Target Warehouse <a href="https://github.com/frappe/erpnext/issues/3970">#3546</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="https://www.believerschurch.com/">Believer's Church</a>
			</td>
			<td>
				Leave Allocation based on Arbitrary Dates <a href="https://github.com/frappe/erpnext/issues/1938">#1938</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="http://agtech.com.sq">AG Technologies, Singapore</a>
			</td>
			<td>
				Bulk edit via export-import in Bank Reconciliation <a href="https://github.com/frappe/erpnext/issues/1938">#4356</a>
			</td>
		</tr>
		<tr>
			<td style="width: 30%">
				<a href="https://www.sapconinstruments.com/">Sapcon Instruments Pvt Ltd</a>
			</td>
			<td>
				Level wise BOM Cost Updation and Performance Enhancement <a href="https://github.com/frappe/erpnext/pull/31072">#31072</a>
			</td>
		</tr>
	</tbody>
</table>
