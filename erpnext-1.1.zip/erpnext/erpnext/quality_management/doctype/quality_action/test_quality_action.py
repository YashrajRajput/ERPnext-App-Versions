# Copyright (c) 2018, Frappe and Contributors
# See license.txt

import unittest


class TestQualityAction(unittest.TestCase):
	# quality action has no code
	pass
