# Copyright (c) 2018, Frappe and Contributors
# See license.txt

import unittest


class TestQualityMeeting(unittest.TestCase):
	# nothing to test
	pass
