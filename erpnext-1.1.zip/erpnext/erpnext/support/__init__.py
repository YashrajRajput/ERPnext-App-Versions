install_docs = [
	{"doctype": "Role", "role_name": "Support Team", "name": "Support Team"},
	{"doctype": "Role", "role_name": "Maintenance User", "name": "Maintenance User"},
	{"doctype": "Role", "role_name": "Maintenance Manager", "name": "Maintenance Manager"},
]
