def get_data():
	return {
		"fieldname": "opportunity",
		"transactions": [
			{"items": ["Quotation", "Request for Quotation", "Supplier Quotation"]},
		],
	}
