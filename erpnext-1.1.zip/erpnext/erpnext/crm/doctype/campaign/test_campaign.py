# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
import unittest


class TestCampaign(unittest.TestCase):
	pass
