// Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
// License: GNU General Public License v3. See license.txt

frappe.query_reports["Quotation Trends"] = $.extend({}, erpnext.sales_trends_filters);
